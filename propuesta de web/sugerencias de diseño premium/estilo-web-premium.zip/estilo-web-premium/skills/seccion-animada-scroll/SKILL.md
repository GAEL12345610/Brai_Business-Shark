---
name: seccion-animada-scroll
description: Crea una sección de web que cuenta una historia mientras haces scroll (GSAP ScrollTrigger con pin) — un objeto se mueve, "se activa" y salen tarjetas de vidrio con logos oficiales que se despliegan explicando cada cosa, y un botón que aparece al final. Ejemplo funcional en ejemplo/seccion-animada.html dentro de esta skill. Usar cuando se pida "animación al bajar", "que se mueva al hacer scroll", "sección animada", "explica el servicio con animación" o "/seccion-animada-scroll".
user-invocable: true
---

# Sección animada al hacer scroll

Ejemplo completo y funcionando: `ejemplo/seccion-animada.html`, dentro de esta misma carpeta (ábrelo en el navegador y baja). Es la sección "Chips NFC" de tuagentedeia.com: el celular baja hasta un chip, salen ondas, la pantalla cambia y aparecen 3 tarjetas (Reseñas en Google, Instagram, WhatsApp).

## Estructura
- Todo vive dentro de la `<section>`: su `<style>` y su `<script>`, con un prefijo de clases propio (`nfx-*`) para no chocar con el resto de la página.
- `.nfx-pin` = grid de 2 columnas (texto | escena), `height:100vh`, padding superior del alto de la barra fija (~96 px) para que quede **centrada debajo de la barra**.
- Escena: objeto que se mueve (teléfono), objetivo (chip con ondas en `@keyframes`) y tarjetas de vidrio con un `<p>` que se despliega (`height:0 → auto`).
- Logos oficiales: trazos de simple-icons (`https://cdn.jsdelivr.net/npm/simple-icons@13.21.0/icons/<nombre>.svg`, se copia el atributo `d`). Google siempre con la G a 4 colores (viewBox `0 0 48 48`, 4 paths, ya en el ejemplo).

## JS (GSAP + ScrollTrigger por CDN)
```js
gsap.timeline({ scrollTrigger: { trigger: seccion, start: 'top top', end: '+=1900',
  pin: seccion.querySelector('.nfx-pin'), scrub: .6, invalidateOnRefresh: true } })
```
Orden de la línea de tiempo:
1. Mover el objeto (`y` y `rotate`, `power2.inOut`).
2. Activar: brillo del objetivo y clase `on` para las ondas (según `progress`).
3. Cambiar lo que muestra la pantalla.
4. Tarjetas una por una (`back.out(1.4)`), y en cada una se despliega su texto.
5. **El botón al final** (`opacity 0→1`, `pointerEvents:'none'→'auto'`), cuando ya se entendió todo.

- Sin GSAP o con `prefers-reduced-motion`: mostrar todo de una vez (`showAll()` en el ejemplo).
- `ScrollTrigger.refresh()` en `load`.
- Opcional: al dar clic al botón, bajar al formulario y preseleccionar la opción correspondiente con `.click()` sobre ella.

## Acomodo que funcionó
- **Computadora:** texto a la izquierda; en la escena, tarjetas en **columna** a un lado y el teléfono al otro (`left:76%`). Nada tapa al teléfono ni al título. Tarjetas grandes (título ~1.2rem, texto 1rem, ícono 50 px).
- **Teléfono (≤860 px):** título y frase arriba, teléfono a la izquierda y tarjetas a la derecha. Las tarjetas **aparecen en su lugar** (no vuelan encima del teléfono).
- **Pantallas chatas** (ej. plegables abiertos 904×640): `@media(min-width:861px) and (max-height:820px){ .nfx-stage{ zoom:.78 } }`. Con `transform:scale` queda hueco.
- **Muy chatas en teléfono** (alto < 760): ocultar el párrafo para que el título no quede bajo la barra.

## Problemas que ya pasaron
- Si la página pone `padding` a todas las `section`, con pin la animación queda corrida hacia abajo. Solución: `padding:0!important` en esta sección.
- Elementos flotantes de la página (mascotas, globos de ayuda) pueden taparla: ocultarlos con una clase en `body` mientras la sección está en pantalla (`ScrollTrigger.create({ onToggle })`).
- Medir en varios tamaños con Playwright y `getBoundingClientRect` (pin, texto, escena) en distintos puntos del scroll, no solo a ojo.
- Al cambiar un `.js` externo, subir su `?v=` para romper caché.

## Reutilizarla para otro servicio
Cambia el objeto (teléfono → laptop, tarjeta, local), el objetivo (chip → botón, sensor) y las 3 tarjetas por los 3 beneficios del servicio. Mantén el orden: movimiento → activación → beneficios uno por uno → botón.
