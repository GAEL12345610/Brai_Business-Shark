const { chromium } = require(require.resolve('playwright', { paths: [process.cwd()] }));

const url = process.argv[2] || 'http://localhost:5630/index.html';
const salida = process.argv[3] || '/tmp/lg-capturas/';
const ids = (process.argv[4] || '').split(',').filter(Boolean);

(async () => {
  require('fs').mkdirSync(salida, { recursive: true });
  const b = await chromium.launch();
  for (const [w, h, t] of [[1440, 900, 'compu'], [390, 844, 'tel']]) {
    const ctx = await b.newContext({ viewport: { width: w, height: h }, isMobile: w < 500, hasTouch: w < 500 });
    const p = await ctx.newPage();
    const errs = [];
    p.on('pageerror', e => errs.push(e.message));
    await p.goto(url, { waitUntil: 'networkidle' });
    await p.waitForTimeout(2000);
    await p.screenshot({ path: salida + t + '-0-inicio.png' });
    const titulo = await p.evaluate(() => {
      const e = document.querySelector('h1');
      if (!e) return null;
      const r = e.getBoundingClientRect();
      return { centroTitulo: Math.round((r.top + r.bottom) / 2), centroPantalla: innerHeight / 2 };
    });
    for (const id of ids) {
      await p.evaluate(i => {
        document.documentElement.style.scrollBehavior = 'auto';
        const e = document.getElementById(i);
        if (e) window.scrollTo(0, e.getBoundingClientRect().top + scrollY);
      }, id);
      await p.waitForTimeout(1300);
      await p.screenshot({ path: salida + t + '-' + id + '.png' });
    }
    console.log(t, titulo, errs.length ? errs : 'sin errores');
    await ctx.close();
  }
  await b.close();
})();
