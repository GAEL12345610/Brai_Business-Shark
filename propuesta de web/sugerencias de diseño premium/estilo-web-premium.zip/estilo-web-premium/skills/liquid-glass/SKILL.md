---
name: liquid-glass
description: Le pone estilo liquid glass (vidrio tipo iPhone) a una web sin rehacerla — una capa CSS + JS encima del diseño actual con fondo de luces suaves, borde de luz, brillo que sigue al mouse, barra flotante de vidrio y menú ☰ en teléfono. Usar cuando se pida "liquid glass", "hazla de vidrio", "estilo iPhone", "hazla más premium" o "/liquid-glass".
user-invocable: true
---

# Liquid glass para cualquier web

Es una **capa encima** del diseño: dos archivos que se cargan al final. No se reescribe el HTML; quitar las dos líneas regresa al diseño original.

- Plantilla: `plantilla/liquid-glass.css` y `plantilla/liquid-glass.js` (en esta carpeta).
- Capturas para revisar: `capturas.js`. Requiere Node.js y Playwright; se instala una vez en la carpeta donde lo vayas a correr:
  ```bash
  npm i playwright@1.48.2
  npx playwright install chromium
  ```

## Funciona mejor en
Webs **oscuras** con tarjetas. En webs claras el vidrio casi no se nota: hay que cambiar los rellenos blancos por oscuros y las luces del fondo por colores más saturados.

## Pasos
1. Trabajar en una **copia local**, nunca directo en producción.
2. Copiar la plantilla a `css/` y `js/` y cargarla:
   - `<link rel="stylesheet" href="css/liquid-glass.css">` antes de `</head>`
   - `<script src="js/liquid-glass.js" defer></script>` antes de `</body>`
   - Si la página tiene CSP, permitir `style-src 'self'` y `script-src 'self'`.
3. Adaptar (tabla abajo).
4. Revisar textos: sin guiones largos, sin frases de relleno.
5. Capturas: `node capturas.js http://localhost:PUERTO/index.html ./capturas/ id1,id2` y revisar en teléfono y computadora.
6. Publicar solo cuando todo se vea bien, con respaldo antes.

## Qué adaptar
| En el CSS | Qué cambiar |
|---|---|
| `:root` `--gold`, `--gold2`, `--gold-g` | El color de acento de la marca |
| `html::before` y `body::before` | Colores de las luces del fondo (el acento + un tono frío suave) |
| Bloque grande de selectores (`.pcard,.ccard,...`) | Las clases de **tarjetas** de tu web (las reglas con `background` + `border-radius`) |
| `#site-nav`, `.top`, `.nav` | El selector de tu barra superior |
| Botones `a[style*="background:var(--gold)"]` | Tus botones principales |
| `.lg-secs` + `.lg-menu` | Solo si agregas menú de secciones |

En el JS solo se adapta `SEL` (las mismas clases de tarjetas, para el brillo del mouse).

## Menú de secciones (opcional)
En la barra: `<div class="lg-secs" id="lgSecs">` con un `<a href="#id">` por sección **en el orden de la página**, y al final:
`<button type="button" class="lg-menu" aria-label="Ver secciones" aria-expanded="false" aria-controls="lgSecs"><span></span><span></span><span></span></button>`.
El JS marca la sección activa y abre/cierra la lista en teléfono. La barra debe caber en **una fila** de 375 a 430 px.

## Reglas del vidrio
1. Necesita algo detrás: luces suaves de color. Sobre negro plano parece tarjeta gris.
2. Siempre un relleno semitransparente, aunque el desenfoque falle, para que el texto se lea.
3. Borde de luz arriba y sombra suave abajo: eso lo hace sentir físico.
4. Pocas capas encimadas; cada desenfoque cuesta rendimiento.
5. Respetar `prefers-reduced-transparency` (vidrio sólido) y `prefers-reduced-motion` (ya viene en la plantilla).
6. Revisar el contraste del texto encima del vidrio, no solo a ojo.

## Problemas que ya pasaron
1. **La refracción SVG sobre video pinta negro** (Chrome): nunca en barras o elementos flotantes que pasan sobre videos; solo en tarjetas y formularios.
2. Si una página no define la variable de color del botón, el texto negro desaparece: definir las variables dentro del propio CSS de vidrio.
3. Brillo blanco del mouse sobre texto gris no se lee: brillo del acento a 0.06 y aclarar los grises (`--dim` ~#bdbdbd).
4. Raya arriba del hero: quitar el `padding-top` viejo y difuminar el final del hero con `mask-image`.
5. El grano de película encima del texto lo vuelve borroso: `z-index:-1`.
6. Capturas negras a medio scroll: usar `scrollTo` instantáneo y esperar antes de concluir que algo está roto.
7. En `@media (max-width:760px)` bajar el desenfoque a 10 px.
