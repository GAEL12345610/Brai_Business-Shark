---
name: estilo-minimalista-premium
description: Sistema de diseño para webs minimalistas, oscuras y premium (estilo editorial de lujo, no "tech startup"): filosofía, paleta, tipografía, espacio, jerarquía, textos, estructura de página, animación sutil y checklist antes de publicar. Usar al diseñar o revisar cualquier página web, landing o sección cuando se pida algo "minimalista", "elegante", "premium", "limpio", "como tuagentedeia.com" o "/estilo-minimalista-premium".
user-invocable: true
---

# Estilo minimalista premium

Referencia viva: **tuagentedeia.com**. La sensación buscada: una revista de lujo, no un software. Oscuro, mucho aire, poco texto, un solo acento de color, movimiento elegante.

## 1 · Filosofía
- **Menos es más.** Si dudas entre poner algo o no, no lo pongas. Cero "relleno": stats de adorno, íconos decorativos, secciones que no aportan.
- **Elegante, nunca ruidoso.** Animaciones sutiles; nada rebota ni gira sin razón.
- **Una idea por sección.** Título que se lee primero, una frase de apoyo y, si hace falta, un botón.
- **La marca manda.** Este sistema es oscuro por defecto, pero si la marca es cálida o luminosa (heladería, panadería) la base va clara/crema. Decide por el público y el logo.
- **Solo material real.** Nunca fotos de stock ni caras inventadas. Logo siempre la imagen real (PNG transparente), nunca recreado con una fuente.

## 2 · Color
Paleta corta: fondo + texto + **un solo acento**.

| Token | Valor | Uso |
|---|---|---|
| `--bg` | `#050505` | Fondo |
| `--bg2` / `--bg3` | `#0c0c0c` / `#121212` | Tarjetas, elevación |
| `--text` | `#f0f0f0` | Texto principal |
| `--dim` | `#999` (sube a `#bdbdbd` sobre vidrio) | Texto secundario |
| `--border` / `--border2` | `#1c1c1c` / `#262626` | Bordes casi invisibles |
| `--gold` / `--gold2` | `#c9a84c` / `#dfc06a` | El acento |
| `--gold-g` | `linear-gradient(135deg,#c9a84c,#dfc06a)` | Botones principales |

- El acento se reserva para **lo que se toca** (botones, links) y para la palabra que remata un título. Nunca en párrafos largos.
- Colores de marcas ajenas solo donde corresponden (verde WhatsApp solo en lo de WhatsApp; rojo solo para errores).
- Glow sutil del acento (`rgba(201,168,76,.2–.4)`) detrás de lo importante; nunca neón.
- Contraste mínimo 4.5:1 (3:1 en texto grande). Gris oscuro sobre negro no pasa.

## 3 · Tipografía
Contraste de 2–3 familias = se ve caro (todas de Google Fonts):
- **Títulos:** sans geométrica fuerte (Space Grotesk 700, `letter-spacing:-.03em`, `line-height:1.02`).
- **La palabra que remata:** serif itálica (Instrument Serif italic) en el acento, con gradiente: `background:var(--gold-g);-webkit-background-clip:text;-webkit-text-fill-color:transparent`.
- **Cuerpo:** sans limpia (Instrument Sans 400, `line-height:1.7`, color `--dim`).
- **Etiquetas / eyebrows:** mono en MAYÚSCULAS (JetBrains Mono 11–13 px, `letter-spacing:.16–.25em`, acento).
- Jerarquía típica de un bloque:
  ```
  ETIQUETA EN MONO
  Título grande *y su remate en itálica dorada.*
  Una frase gris de apoyo, corta.
  [ Botón ]
  ```
- Nada de pesos Light/Thin sobre fondos oscuros. Si un texto se ve delgado, cámbialo a una itálica con más cuerpo, no solo lo agrandes.
- Renglones de 60–75 caracteres (`max-width:460–560px`). `text-wrap:balance` en títulos.
- Tracking amplio solo en etiquetas en mayúsculas, nunca en frases normales.

## 4 · Espacio y jerarquía
- Secciones con `padding` vertical generoso (~110 px escritorio, ~70 px teléfono) y un borde superior de 1 px casi invisible entre secciones.
- Agrupa con espacio, no con líneas. Más espacio arriba de un título que debajo.
- Entre niveles de texto el tamaño cambia 1.5–2×; si cambia poco, no se nota.
- **Un solo botón principal por pantalla.** Prueba de ojos entrecerrados: el título y el botón se siguen viendo.
- Botón principal: píldora con `--gold-g`, texto negro 700, sombra dorada suave, hover `translateY(-3px)`.
- Esquinas: tarjetas redondeadas (18–22 px), píldoras 99 px.
- Contenedor máximo ~1180 px centrado.

## 5 · Componentes que dan el "look"
- **Tarjetas de vidrio** (ver skill `liquid-glass`): relleno semitransparente + `backdrop-filter:blur(14px)` + borde 1 px del acento a ~30 % + `inset 0 1px 0 rgba(255,255,255,.05)` arriba + sombra suave abajo. Necesitan luces de color detrás; sobre negro plano se ven grises.
- **Etiquetas píldora** en mono con borde del acento a 30 % y fondo del acento a 5 %.
- **Íconos:** línea fina en el acento, o los logos oficiales a color de las marcas (simple-icons), nunca emojis como logo.
- **Barra superior flotante** de vidrio, en una sola fila; en teléfono se simplifica a lo esencial + botón ☰.

## 6 · Movimiento
- Entradas al hacer scroll: fade + desplazamiento corto (20–30 px) con stagger; easing `power2.out` / `easeOutCubic`.
- Hover con glow del acento en las orillas.
- Para explicar un servicio: una **sección con pin al hacer scroll** que cuente la historia en pasos (skill `seccion-animada-scroll`).
- **Regla crítica:** las animaciones nunca dejan contenido oculto. El estado oculto se aplica solo si la librería cargó, con red de seguridad que revela todo, y respetando `prefers-reduced-motion`.
- Nivel por defecto ~6/10: notorio pero elegante.

## 7 · Textos
- Frases cortas. Una idea por frase. Se habla de tú.
- Como se lo dirías a un cliente en persona. Prohibido: "soluciones digitales", "sin fricción", "potencia tu negocio", "transformación digital".
- Sin guiones largos (—): cámbialos por punto, coma o dos puntos.
- Evita las listas de tres por costumbre y las frases sueltas tipo "Simple. Rápido. Fácil."
- Lenguaje del cliente, no técnico ("sistema", no "workflow").
- Todo en un idioma, sin selector de idioma.

## 8 · Estructura de una landing (one-pager)
1. Hero: título grande (o logo grande) + 1 botón. Sin frases de relleno ni "scroll ↓".
2. El problema (lo que pierde el cliente) en 3–4 tarjetas.
3. Cada servicio en su sección, con una demo visual (chat, llamada, animación).
4. Prueba real (casos, reseñas reales con nombre).
5. Contacto: formulario corto o botón directo a WhatsApp con mensaje prellenado.
6. Footer mínimo.

## 9 · Técnico
- HTML/CSS/JS sin frameworks; fuentes de Google Fonts; GSAP + ScrollTrigger por CDN.
- Mobile first. Probar en 390 px (teléfono), 640–980 px (tablets y plegables, el rango que más se rompe) y 1440 px.
- Pocas capas de `backdrop-filter` encimadas; en teléfono bajar el blur a ~10 px.
- Videos: MP4 propios, mudos, autoplay, loop, playsinline. Nunca embeds de YouTube.
- SEO invisible: title, description, Open Graph, favicon con el logo real, JSON-LD.
- Al cambiar un `.js` o `.css`, subir su `?v=` para romper caché.

## 10 · Checklist antes de publicar
- [ ] Se entiende qué vendes en 3 segundos.
- [ ] Un solo botón principal visible sin scroll en teléfono.
- [ ] Nada tapa a nada en 390, 640, 904 y 1440 px.
- [ ] Contraste suficiente, sobre todo encima del vidrio.
- [ ] Consola sin errores. Animaciones no dejan nada oculto.
- [ ] Sin fotos de stock, sin logos recreados, sin textos de relleno.
