# Estilo web minimalista premium

El estilo de **tuagentedeia.com** documentado para reutilizarlo: oscuro, con mucho aire, poco texto, un solo color de acento, vidrio tipo iPhone y animaciones elegantes al hacer scroll.

## Qué trae

| Carpeta | Qué es |
|---|---|
| `REGLAS.md` | Las reglas esenciales en una hoja: qué sí, qué no y checklist. **Empieza aquí.** |
| `skills/estilo-minimalista-premium/` | El sistema de diseño completo: filosofía, colores, tipografías, espacio, textos, estructura  y checklist. |
| `skills/liquid-glass/` | Capa de vidrio tipo iPhone que se pone encima de cualquier web (CSS + JS listos en `plantilla/`). |
| `skills/seccion-animada-scroll/` | Cómo hacer una sección que cuenta una historia al hacer scroll (teléfono, chip, tarjetas que aparecen). |
| `ejemplos/componentes.html` + `estilo-base.css` | Página de ejemplo con cada pieza: hero, tarjetas, pasos 01–04, vidrio, píldoras, botones y animación al aparecer. El CSS se copia tal cual para empezar una web. |
| `skills/seccion-animada-scroll/ejemplo/seccion-animada.html` | La sección animada funcionando sola. Ábrela en el navegador y baja. |

## Cómo usarlo con Claude Code
Copia las carpetas de `skills/` a `~/.claude/skills/`:

```bash
cp -R skills/* ~/.claude/skills/
```

Luego en Claude Code puedes pedir, por ejemplo:
- "Diseña la landing de mi negocio con `/estilo-minimalista-premium`"
- "Ponle `/liquid-glass` a mi web"
- "Haz una `/seccion-animada-scroll` para explicar mi servicio"

También se pueden leer como guía normal, sin Claude.

## Lo esencial en 6 líneas
1. Menos es más: si dudas en poner algo, no lo pongas.
2. Fondo `#050505`, texto `#f0f0f0`, **un** acento (`#c9a84c`) solo en lo que se toca y en la palabra que remata.
3. Títulos en sans fuerte + remate en serif itálica dorada + etiquetas en mono mayúsculas.
4. Un botón principal por pantalla.
5. Vidrio con luces detrás, nunca sobre negro plano.
6. Animaciones que cuentan algo, sin rebotes, y que nunca dejan contenido oculto.

Fuentes (Google Fonts): Space Grotesk, Instrument Sans, Instrument Serif, JetBrains Mono. Animación: GSAP + ScrollTrigger.
