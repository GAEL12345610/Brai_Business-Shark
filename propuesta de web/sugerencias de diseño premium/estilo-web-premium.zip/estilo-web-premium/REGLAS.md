# Reglas esenciales

Las reglas que hacen que el estilo funcione. Si solo lees una hoja, que sea esta.

## Sí

1. **Menos es más.** Si dudas en poner algo, no lo pongas.
2. **Un solo color de acento** (`#c9a84c`), solo en lo que se toca (botones, links) y en la palabra que remata el título.
3. **Fondo casi negro** (`#050505`) y texto casi blanco (`#f0f0f0`). Gris (`#999`) para texto de apoyo.
4. **Títulos que rematan en itálica dorada:** "Un título corto *que remata en dorado.*"
5. **Etiqueta en mayúsculas mono** arriba de cada título, con letras separadas.
6. **Un botón principal por pantalla.** Píldora dorada con texto negro.
7. **Mucho aire:** ~110 px entre secciones en computadora, ~70 px en teléfono.
8. **Renglones cortos:** 60 a 75 letras como máximo.
9. **Pasos numerados como 01 02 03 04**, en mono.
10. **Íconos de línea fina dorada**, o logos oficiales a color (simple-icons). Nunca emojis como logo.
11. **Vidrio con luces de color detrás**, relleno semitransparente, borde de luz arriba y sombra abajo.
12. **Animaciones que cuentan algo:** aparecer al hacer scroll, hover con brillo dorado, secciones que explican un servicio paso a paso.
13. **Material real:** fotos, videos y logos verdaderos de la marca.
14. **Probar en teléfono (390 px), plegables y tablets (640 a 980 px) y computadora (1440 px).**

## No

1. Fotos de stock, caras inventadas o logos recreados con una fuente.
2. Más de un color de acento, arcoíris o gradientes agresivos.
3. Letra delgada (Light/Thin) sobre fondo oscuro.
4. Párrafos largos, stats de adorno, secciones de relleno.
5. Frases de agencia: "soluciones digitales", "sin fricción", "potencia tu negocio", "transformación digital".
6. Guiones largos (—) y listas de tres por costumbre ("rápido, fácil y seguro").
7. Cosas que rebotan, giran o parpadean sin razón.
8. Animaciones que dejan contenido oculto si algo falla.
9. Embeds de YouTube: videos MP4 propios, mudos, en loop.
10. Muchas capas de vidrio encimadas (cuestan rendimiento en teléfonos).

## Antes de publicar

- [ ] Se entiende qué vendes en 3 segundos.
- [ ] El botón principal se ve sin hacer scroll en el teléfono.
- [ ] Nada tapa a nada en ningún tamaño.
- [ ] Contraste suficiente, sobre todo encima del vidrio.
- [ ] Consola del navegador sin errores.
